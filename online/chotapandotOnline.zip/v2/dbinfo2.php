<?php
$servername = "localhost";
$username = "u853693918_data";
$password = "44BbHYywcV9YRKV7";
$dbname = "u853693918_data";
?>